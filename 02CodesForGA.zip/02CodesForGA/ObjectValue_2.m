function DD = ObjectValue_2(PP,PP_sita,q)
%����Ŀ�꺯��

len = length(q);

for ii = 1:len
    
%     pH = max(abs(PP_sita(1,:)))  ./ max(abs((PP(1,:))));
%     pD = max(abs(PP_sita(2,:)))  ./ max(abs((PP(2,:))));
%     pZ = max(abs(PP_sita(3,:)))  ./ max(abs((PP(3,:))));
%     PP_sita(1,:) = PP_sita(1,:) / pH;
%     PP_sita(2,:) = PP_sita(2,:) / pH;
%     PP_sita(3,:) = PP_sita(3,:) / pH;
    
    
     PP_temp = transfer_2(PP,q(ii,1),q(ii,2),q(ii,3),q(ii,4),q(ii,5),q(ii,6));
    
%     DD_1 = corrcoef(PP_temp(1,:),PP_sita(1,:));
%     DD_1 = DD_1(1,2);
%     DD_2 = corrcoef(PP_temp(2,:),PP_sita(2,:));
%     DD_2 = DD_2(1,2);
%     DD_3 = corrcoef(PP_temp(3,:),PP_sita(3,:));
%     DD_3 = DD_3(1,2);
%     
%     DD(ii) = sum([DD_1,DD_2,DD_3]);
% end
% DD = -1 * DD';

% c=PP_temp-PP_sita;
% d=c.^2;
% DD(ii)=sum(d(:));
c1=PP_temp(1,:)-PP_sita(1,:);
d1=c1.^2;
c2=PP_temp(2,:)-PP_sita(2,:);
d2=c2.^2;
c3=PP_temp(3,:)-PP_sita(3,:);
d3=c3.^2;
DD(ii)=sum([d1,d2,d3]);
end
DD = DD';
