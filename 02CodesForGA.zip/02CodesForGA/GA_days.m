%%%��ͨ�Ŵ��������ݹ���GA����-----Zhaobo He; Xingxing Hu; Yuntian Teng;Xiuxia Zhang; Xiaoyu Shen

% A GA method to calculate the attitude angles and scale factors between
% tested instruments data and a standard one.
% This program code is a prototype which can only calculate one month results eachtime. 
% If you want to calculate long-term parameters, you need to change the data month when insert the data sets.
% Use file "readme.txt" to modify details.


close all;clear;clc
is = 1;ie = 31; %From day (is = 1) to day 31(ie = 31),for example. The number of days may different for different months.
Q_huizong = zeros(ie-is+1,6);   %Q_huizong is the array for results of each days. 
                                %The first to third columns are attitudes angles (roll, pitch, yaw, in turn), and the fourth to sixth colum are scale factors.
tic
for ii = is:ie
tic

%Tested dataset
%Please change data path for different datasets and data month.
% For LIJ observatory ,
PathName = 'C:\Users\HeZB\Desktop\01DatasetsForGA\LIJ\inst3-noerror\'; month = 'inst3_202001';
% For YUL ,PathName = 'C:\Users\HeZB\Desktop\01DatasetsForGA\YUL\inst6-noerror\'; month = 'inst6_202005';
% For MAG, PathName = 'C:\Users\HeZB\Desktop\01DatasetsForGA\MAG\inst3-noerror\'; month = 'inst3_202001';

% Please pay attention to replace variation "month" which should be changed due to the name of raw datasets.  

beice = [];
for i = 1:1
fn = [PathName month num2str(ii,'%05.2u') '-noerror' '.txt'];
A = importdata(fn);
beice = [beice;A];
end
%��׼��������
%Standard dataset
% For LIJ observatory ,
PathName = 'C:\Users\HeZB\Desktop\01DatasetsForGA\LIJ\inst2-noerror\'; month = 'inst2_202001';
% For YUL ,PathName = 'C:\Users\HeZB\Desktop\01DatasetsForGA\YUL\inst5-noerror\'; month = 'inst5_202005';
% For MAG, PathName = 'C:\Users\HeZB\Desktop\01DatasetsForGA\MAG\inst2-noerror\'; month = 'inst2_202001';

% The relationship between the test instrument and the standard instrument is not absolute. 
% However, we usually choose to have better stability, first installing the instrument for observation at the observatory as a standard instrument.

biaozhun = [];
for i = 1:1
fn = [PathName month num2str(ii,'%05.2u') '-noerror' '.txt'];
A = importdata(fn);
biaozhun = [biaozhun;A];
end
toc

% pic_title = ['����2020��01' '��' num2str(ii,'%05.2u') '��' 'ȥ��ֵԭʼ�����������׼���ݶԱ�'];
pic_title = ['LIJ 2020-XX-'  num2str(ii,'%05.2u')  ': Raw data comparasion'];
pic_title_2 = ['LIJ 2020-XX-'  num2str(ii,'%05.2u')  ': Corrected data comparasion'];

gm4_111 = beice;
gm4_180 = biaozhun;

%% ��ԭʼ����
% Raw data processing(decrease the baselines)
ind = 1:length(gm4_111(:,1));

H_111 = gm4_111(:,2) - mean(gm4_111(1:end,2));
D_111 = gm4_111(:,3) - mean(gm4_111(1:end,3));
Z_111 = gm4_111(:,1) - mean(gm4_111(1:end,1));
T_111 = gm4_111(:,4);


H_180 = gm4_180(:,2) - mean(gm4_180(1:end,2));
D_180 = gm4_180(:,3) - mean(gm4_180(1:end,3));
Z_180 = gm4_180(:,1) - mean(gm4_180(1:end,1));
T_180 = gm4_180(:,4);

figure(1+(ii)*10)

scrsz = get(0,'ScreenSize');
adjx = round(0.3 * scrsz(3));
adjy = round(0.1 * scrsz(4));
scrsz = [ 100 adjy (scrsz(3) - (2 * adjx)) (scrsz(4)- (2 * adjy)) ];
set(gcf, 'Position', scrsz);


for i=1:8 
    switch i
    case 1
        %[0.13,0.7,0.77,0.2]----0.13����ߣ�0.7���±ߣ�0.77���ұߡ�0.2�Ǹ߶�
        subplot('Position',[0.13,0.8,0.77,0.1]),plot(ind,H_111,'r');
        title(pic_title,'fontsize',22);
        ylabel('H(nT)','fontsize',14);axis tight;
        hold on, plot(ind,H_180,'k');
        legend('tested','standard','Location','northeast');
    case 2
        subplot('Position',[0.13,0.7,0.77,0.1])
        plot(ind,H_111-H_180,'k');
        ylabel('dH(nT)','fontsize',14);axis tight;
    case 3
        subplot('Position',[0.13,0.6,0.77,0.1]),plot(ind,D_111,'r');
        ylabel('D(nT)','fontsize',14);axis tight;
        hold on, plot(ind,D_180,'k');
    case 4
        subplot('Position',[0.13,0.5,0.77,0.1]),plot(ind,D_111-D_180,'k');
        ylabel('dD(nT)','fontsize',14);axis tight;
    case 5
        subplot('Position',[0.13,0.4,0.77,0.1]),plot(ind,Z_111,'r');
        ylabel('Z(nT)','fontsize',14);axis tight;
        hold on, plot(ind,Z_180,'k');
    case 6
        subplot('Position',[0.13,0.3,0.77,0.1]),plot(ind,Z_111-Z_180,'k');
        ylabel('dZ(nT)','fontsize',14);axis tight;
    case 7
        subplot('Position',[0.13,0.2,0.77,0.1]),plot(ind,T_111,'r');
        ylabel('T(��)','fontsize',14);axis tight;
        hold on, plot(ind,T_180,'k');
    otherwise
        subplot('Position',[0.13,0.1,0.77,0.1]),plot(ind,T_111-T_180,'k');axis tight;
%         ylim([19 21])
        xlim([0 inf])
        ylabel('dT(��)','fontsize',14)
    end
    xlabel('ʱ��()','fontsize',14)
%     xticks(XT)
%     xticklabels(XTL)
end

%% �������Ƕ�
%Calculate attitude angles

Q = zeros(10,6);% repeat 10 times calculations to decrease the calculation difference due to GA methods.
tic
for j = 1:length(Q(:,1))
[q1,q2,q3,q4,q5,q6] = jiaodufanyan_gen(H_111,D_111,Z_111,H_180,D_180,Z_180);
Q(j,:) = [q1,q2,q3,q4,q5,q6];
end
toc
STD = std(Q);
len = length(Q(:,1));
%% �޳��ϴ�ƫ��Ľ������������ֵ���׼��
% Remove large diviation results and calculate the meanvalue and standard diviation of attitude angles results

a = 0;
for j = 1:len
    if ((abs(Q(j,1)-mean(Q(:,1)))>STD(1)&&STD(1)>0.001)||(abs(Q(j,2)-mean(Q(:,2)))>STD(2)&&STD(2)>0.001)||...
            (abs(Q(j,3)-mean(Q(:,3)))>STD(3)&&STD(3)>0.001)||(abs(Q(j,4)-mean(Q(:,4)))>STD(4)&&STD(4)>0.001)||...
            (abs(Q(j,5)-mean(Q(:,5)))>STD(5)&&STD(5)>0.001)||(abs(Q(j,6)-mean(Q(:,6)))>STD(6)&&STD(6)>0.001))   
    else
         a = a+1; QQ(a,:) = Q(j,:);         
    end
end

Q_means = zeros(1,6);
Y = [H_111,D_111,Z_111];
for k = 1:6
    Q_means(1,k) = mean(QQ(:,k));
end

%% �����任����󲢶Ա�У���󱻲��������׼����
% Form the transfer martrix and compare the corrected tested data with
% standard data
YY = transfer_2(Y,Q_means(1,1),Q_means(1,2),Q_means(1,3),Q_means(1,4),Q_means(1,5),Q_means(1,6));
% Q=[Q_means(1,1),Q_means(1,2),Q_means(1,3),Q_means(1,4),Q_means(1,5),Q_means(1,6)];

figure(2+(ii)*10)

scrsz = get(0,'ScreenSize');
adjx = round(0.3 * scrsz(3));
adjy = round(0.1 * scrsz(4));
scrsz = [ 1000 adjy (scrsz(3) - (2 * adjx)) (scrsz(4)- (2 * adjy)) ];
set(gcf, 'Position', scrsz);

for i=1:8 
    switch i
    case 1
        %[0.13,0.7,0.77,0.2]----0.13����ߣ�0.7���±ߣ�0.77���ұߡ�0.2�Ǹ߶�
        subplot('Position',[0.13,0.8,0.77,0.1]),plot(ind,YY(1,:),'r');
        title(pic_title_2,'fontsize',22);
        ylabel('H(nT)','fontsize',14);axis tight;
        hold on, plot(ind,H_180','k');
        legend('tested','standard','Location','northeast');
    case 2
        subplot('Position',[0.13,0.7,0.77,0.1])
        plot(ind,YY(1,:)-H_180','k');
        ylabel('dH(nT)','fontsize',14);axis tight;
    case 3
        subplot('Position',[0.13,0.6,0.77,0.1]),plot(ind,YY(2,:),'r');
        ylabel('D(nT)','fontsize',14);axis tight;
        hold on, plot(ind,D_180','k');
    case 4
        subplot('Position',[0.13,0.5,0.77,0.1]),plot(ind,YY(2,:)-D_180','k');
        ylabel('dD(nT)','fontsize',14);axis tight;
    case 5
        subplot('Position',[0.13,0.4,0.77,0.1]),plot(ind,YY(3,:),'r');
        ylabel('Z(nT)','fontsize',14);axis tight;
        hold on, plot(ind,Z_180','k');
    case 6
        subplot('Position',[0.13,0.3,0.77,0.1]),plot(ind,YY(3,:)-Z_180','k');
        ylabel('dZ(nT)','fontsize',14);axis tight;
    case 7
        subplot('Position',[0.13,0.2,0.77,0.1]),plot(ind,T_111,'r');
        ylabel('T(��)','fontsize',14);axis tight;
        hold on, plot(ind,T_180,'k');
    otherwise
        subplot('Position',[0.13,0.1,0.77,0.1]),plot(ind,T_111-T_180,'k');axis tight;
%         ylim([19 21])
        xlim([0 inf])
        ylabel('dT(��)','fontsize',14)
    end
    xlabel('ʱ��()','fontsize',14)
%     xticks(XT)
%     xticklabels(XTL)
end

Q_huizong(ii,:) = Q_means(1,:);
end
toc