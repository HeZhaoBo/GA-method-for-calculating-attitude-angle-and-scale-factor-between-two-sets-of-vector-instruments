The program can be found in github with URL: 
https://github.com/HeZhaoBo/GA-method-for-calculating-attitude-angle-and-scale-factor-between-two-sets-of-vector-instruments